//============================================================================
// Name        : Directory.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include "Directory.hpp"
#include <iostream>
using namespace std;

struct Input{
	string nameF;
	string nameM;
	string nameL;
	string ID;
	string Age;
};
struct Ouput{
	string nameF;
	string nameM;
	string nameL;
	string ID;
	string Des;
};
struct Student{
	string nameF;
	string nameM;
	string nameL;
	int loc;
	int seq
	short int Age;
};

int ageCalc(Student *[]ray, Student *& age)
{

};
