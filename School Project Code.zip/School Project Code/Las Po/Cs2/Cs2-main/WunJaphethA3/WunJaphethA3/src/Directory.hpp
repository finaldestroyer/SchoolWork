//============================================================================
// Name        : Directory.h
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#ifndef	DIRECTORY_HPP_
#define DIRECTORY_HPP_

using namespace stf;
#include <string>

struct Input{};
struct Ouput{};
struct Student{};

int ageCalc(Student *[]ray, Student *& age){};



#endif /* DIRECTORY_HPP_ */
