//============================================================================
// Name        : bus.h
// Author      :
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#ifndef	DIRECTORY_HPP_
#define DIRECTORY_HPP_

using namespace std;
#include <string>
//////Setters////
	void setBusID(string x){}
    void setManufact(string x){}
    void setCapacity(int x){}
    void setMilage(int x){}
    void setStatus(char x){}
//////Getters/////
    string getBusID(){}
    string getManufact(){}
    int getCapacity(){}
    int getMilage(){}
    char getStatus(){}




#endif /* BUS_HPP_ */
