#include <iostream>

using namespace std;

int main()
{
    
/*    Pick two main concepts or aspects of C++ syntax.
    Make your own short example of each being used in a program.
    Include all examples in one program, and provide comments (with "//" marks) explaining your code. 
*/
  //Concept #1 COUT
    cout<<"Hello World";
    // prints Hello World
  //Concept #2 Variables
    string something =""
    //created a variable type string called something
  //Concept #3 CIN
    cin>something
    //ask for user input
    return 0;
}
